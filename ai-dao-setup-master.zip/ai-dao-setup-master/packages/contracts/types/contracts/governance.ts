export interface Proposal {
  id: number;
  title: string;
  description: string;
  status: string;
  votes: number;
}
