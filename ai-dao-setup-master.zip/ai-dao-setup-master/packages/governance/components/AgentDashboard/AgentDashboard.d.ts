import React from 'react';
export default function AgentDashboard(): React.JSX.Element;
