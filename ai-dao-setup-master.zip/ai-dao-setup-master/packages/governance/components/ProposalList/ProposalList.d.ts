import React from 'react';
export default function ProposalList(): React.JSX.Element;
