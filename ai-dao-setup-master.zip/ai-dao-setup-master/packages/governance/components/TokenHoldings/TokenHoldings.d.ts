import React from 'react';
export default function TokenHoldings(): React.JSX.Element;
