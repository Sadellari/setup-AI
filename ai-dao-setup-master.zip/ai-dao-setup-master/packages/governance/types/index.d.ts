export * from './proposal';
export { TreasuryState, Investment } from './treasury';
//# sourceMappingURL=index.d.ts.map